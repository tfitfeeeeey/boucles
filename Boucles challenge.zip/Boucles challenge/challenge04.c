/*Challenge 4 : Affichage des N Premiers Nombres Impairs
Écrivez un programme C qui demande un nombre entier n et affiche les n premiers nombres impairs.
Par exemple, pour n = 5, affichez : 1, 3, 5, 7, 9.*/

#include <stdio.h>

int main() {
    int n, i = 0, nombre = 1;

    printf("Entrez un nombre entier: ");
    scanf("%d", &n);

    printf("Les %d premiers nombres impairs sont: ", n);

    while(i < n) {
        printf("%d ", i);
        nombre += 2; 
        i++;
    }

    printf("\n");

    return 0;
}
