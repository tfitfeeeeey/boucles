    /*
    Challenge 8 : Affichage de la Suite de Fibonacci
    Écrivez un programme C qui génère les n premiers termes de la suite de Fibonacci, où n est entré par l’utilisateur.
    La suite de Fibonacci est définie comme suit : F(0) = 0, F(1) = 1, et F(n) = F(n-1) + F(n-2).*/


#include <stdio.h>

int main() {
    int n, terme1 = 0, terme2 = 1, termeSuivant;

    printf("Entrez un nombre entier (n): ");
    scanf("%d", &n);

    printf("Les %d premiers termes de la suite de Fibonacci sont: \n", n);

    for(int i = 0; i < n; i++) {
        if(i == 0) {
            printf("%d ", terme1);  
        } else if(i == 1) {
            printf("%d ", terme2); 
        } else {
            termeSuivant = terme1 + terme2;
            printf("%d ", termeSuivant);
            terme1 = terme2;
            terme2 = termeSuivant;
        }
    }

    printf("\n");

    return 0;
}

