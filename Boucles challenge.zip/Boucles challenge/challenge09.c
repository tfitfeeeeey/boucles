/*Challenge 9 : Compteur de Chiffres
Écrivez un programme C qui demande à l’utilisateur un entier positif et compte le nombre de chiffres dans cet entier.
Par exemple, pour n = 12345, affichez : Nombre de chiffres = 5.*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i;

    printf("saisie un nombre :\n");
    scanf("%d",&n);

    i=0;
    do{
        n=n/10;
        i++;

    }while(n!=0);
    printf("le nombre contient %d chiffres",i);
    return 0;
}
