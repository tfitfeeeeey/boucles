/*Challenge 6 : Affichage des N Premiers Nombres Pair
Écrivez un programme C qui demande un nombre entier n et affiche les n premiers nombres pairs.
Par exemple, pour n = 4, affichez : 2, 4, 6, 8.
*/


#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i,counter=0;


    printf("entre le nombre d_affichage : ");
    scanf("%d",&n);

    do{
            i++;
        if((i%2)==0){
            printf("%d",i);
            counter++;
        }
        continue;
    }while(counter<n);
    return 0;
}
