/*Challenge 5 : Calcul de la Puissance
Écrivez un programme C qui calcule la puissance d'un nombre entier base élevé à un exposant exposant.
Utilisez une boucle pour effectuer le calcul.
Par exemple, pour base = 3 et exposant = 4, le résultat est 3^4 = 81.*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int b,e,i;
    double r=1.0;
    printf("entrer la base : ");
    scanf("%d",&b);
    printf("entrer l_exposant: ");
    scanf("%d",&e);

    for (i=1;i<=e;i++){
          r=r*b ;

    }printf("%.2f",r);

    return 0;
}
