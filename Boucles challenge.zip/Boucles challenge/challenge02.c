/*Challenge 2 : Factorielle d'un Nombre
Écrivez un programme C qui calcule la factorielle d'un nombre entier positif n entré par l’utilisateur.
La factorielle de n est le produit de tous les entiers positifs inférieurs ou égaux à n. Par exemple,
pour n = 5, affichez : 5! = 120.*/

#include <stdio.h>

int main () {
    int L;
    printf("Saisir le nombre de lignes : ");
    scanf("%d",&L);
    for(int i=0; i<L; i++) {
        for(int j=i+1; j<L ; j++) printf(" ");
        for(int j=0; j<2*i+1; j++) printf("*");
        printf("\n");
    }
    return 0;
}
