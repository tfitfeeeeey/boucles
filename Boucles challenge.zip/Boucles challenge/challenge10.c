/*Challenge 10 : Calcul de la Somme des N Entiers
Écrivez un programme C qui demande à l’utilisateur
un nombre entier n et calcule la somme des n premiers entiers naturels en utilisant une boucle
Par exemple, pour n = 3, la somme est 1 + 2 + 3 = 6*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i,res;

    printf("donner un nombre:");
    scanf("%d",&n);

     res=0;
    for(i=0;i<=n;i++){
        res+=i;
    }printf("resultat est : %d",res);

    return 0;
}
